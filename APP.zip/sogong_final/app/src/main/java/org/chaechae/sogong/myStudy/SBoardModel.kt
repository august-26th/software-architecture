package org.chaechae.sogong.myStudy

data class SBoardModel (
    val title: String="",
    val content:String="",
    val uid: String="",
    val time: String="",
    val category:String=""

)