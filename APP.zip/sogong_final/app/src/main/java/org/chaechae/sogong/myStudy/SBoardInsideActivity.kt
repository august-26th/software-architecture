package org.chaechae.sogong.myStudy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import org.chaechae.sogong.Board.BoardEditActivity
import org.chaechae.sogong.Board.BoardInsideActivity
import org.chaechae.sogong.R
import org.chaechae.sogong.comment.CommentModel
import org.chaechae.sogong.databinding.ActivitySboardInsideBinding
import org.chaechae.sogong.sComment.SCommentLVAdapter
import org.chaechae.sogong.sComment.SCommentModel
import org.chaechae.sogong.utils.FBAuth
import org.chaechae.sogong.utils.FBRef

class SBoardInsideActivity : AppCompatActivity() {

    private lateinit var binding:ActivitySboardInsideBinding
    private val TAG= SBoardInsideActivity::class.java.simpleName
    private lateinit var key:String
    private val sCommentDataList= mutableListOf<SCommentModel>()
    private lateinit var sCommentAdapter:SCommentLVAdapter

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sboard_inside)

        binding=DataBindingUtil.setContentView(this,R.layout.activity_sboard_inside)

        binding.boardSettingIcon.setOnClickListener{
            showDialog()
        }

        key=intent.getStringExtra("key").toString()

        getSBoardData(key)
        getImageData(key)

        binding.commentBtn.setOnClickListener{
            insertComment(key)
        }

        binding.commentBtn.setOnClickListener{
            insertComment(key)
        }

        getCommentData(key)

        sCommentAdapter= SCommentLVAdapter(sCommentDataList)
        binding.commentLV.adapter=sCommentAdapter



    }

    fun getCommentData(key: String){

        val postListener=object :ValueEventListener{
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                sCommentDataList.clear()

                for(dataModel in dataSnapshot.children){
                    val item=dataModel.getValue(SCommentModel::class.java)
                    sCommentDataList.add(item!!)
                }

                sCommentAdapter.notifyDataSetChanged()
            }

            override fun onCancelled(databaseerror: DatabaseError) {
                Log.w(TAG, "loadPost:onCancelled",databaseerror.toException())
            }
        }

        FBRef.sCommentRef.child(key).addValueEventListener(postListener)

    }

    fun insertComment(key: String) {
        FBRef.sCommentRef
            .child(key)
            .push()
            .setValue(
                SCommentModel(
                            binding.commentArea.text.toString(),
                            FBAuth.getTime()
                )
            )

        Toast.makeText(this, "댓글 입력 완료", Toast.LENGTH_LONG).show()
        binding.commentArea.setText("")
    }

    private fun showDialog(){

        val mDialogView= LayoutInflater.from(this).inflate(R.layout.custom_dialog,null)
        val mBuilder=AlertDialog.Builder(this)
            .setView(mDialogView)
            .setTitle("게시글 수정/삭제")

        val alertDialog=mBuilder.show()

        //게시글 수정
        alertDialog.findViewById<Button>(R.id.editBtn)?.setOnClickListener{
            Toast.makeText(this,"수정 버튼을 눌렀습니다.",Toast.LENGTH_LONG).show()

            val intent= Intent(this,SBoardEditActivity::class.java)
            intent.putExtra("key",key)
            startActivity(intent)
       }

        //게시글 삭제
        alertDialog.findViewById<Button>(R.id.removeBtn)?.setOnClickListener{
            FBRef.sBoardRef.child(key).removeValue()
            Toast.makeText(this,"삭제 완료",Toast.LENGTH_LONG).show()
            finish()
        }

    }


    private fun getImageData(key: String){
        // Reference to an image file in Cloud Storage
        val storageReference = Firebase.storage.reference.child(key+".png")

        // ImageView in your Activity
        val imageViewFromFB = binding.getImageArea

        storageReference.downloadUrl.addOnCompleteListener(OnCompleteListener{ task->
            if(task.isSuccessful){

                Glide.with(this)
                    .load(task.result)
                    .into(imageViewFromFB)
            } else{

            }
        })
    }


    private fun getSBoardData(key:String){

        val postListener=object: ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot){


                try{
                    val sDataModel=dataSnapshot.getValue(SBoardModel::class.java)

                    binding.titleArea.text=sDataModel!!.title
                    binding.textArea.text=sDataModel!!.content
                    binding.timeArea.text=sDataModel!!.time

                    val myUid= FBAuth.getUid()
                    val writerUid=sDataModel.uid

                    if(myUid.equals(writerUid)){
                        binding.boardSettingIcon.isVisible = true
                    }


                }catch (e:Exception){
                    Log.d(TAG,"삭제 완료")

                }
            }

            override fun onCancelled(databaseError:DatabaseError){
                Log.w(TAG,"loadPost:onCancelled",databaseError.toException())
            }
        }
        FBRef.sBoardRef.child(key).addValueEventListener(postListener)
    }
}