package org.chaechae.sogong.sComment

data class SCommentModel (
    val commentTitle:String="",
    val commentCreatedTime:String=""


)
