package org.chaechae.sogong.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.navigation.findNavController
import org.chaechae.sogong.Board.EntitleActivity
import org.chaechae.sogong.R


class HomeFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        val view=inflater.inflate(R.layout.fragment_home,container,false)


        view.findViewById<ImageButton>(R.id.button4).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","1") //전체
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button5).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","2") //어학
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button6).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","3") //취업
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button7).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","4") //입시
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button8).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","5") //IT
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button9).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","6") //고시
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button10).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","7") //취미
            startActivity(intent)
        }

        view.findViewById<ImageButton>(R.id.button11).setOnClickListener {
            val intent=Intent(context,EntitleActivity::class.java)
            intent.putExtra("data","8") //기타
            startActivity(intent)
        }


        view.findViewById<ImageView>(R.id.manual).setOnClickListener{
            val intent=Intent(Intent.ACTION_VIEW, Uri.parse("https://www.notion.so/a2879b7163ba484c9c2e43a20fde2774"))
            startActivity(intent)
        }



        return view
    }


}