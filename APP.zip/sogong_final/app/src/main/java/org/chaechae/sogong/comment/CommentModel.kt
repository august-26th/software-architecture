package org.chaechae.sogong.comment

class CommentModel (
    val commentTitle:String="",
    val commentCreatedTime:String=""
)