package org.chaechae.sogong.myStudy

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.databinding.DataBindingUtil
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import org.chaechae.sogong.Board.BoardModel
import org.chaechae.sogong.R
import org.chaechae.sogong.databinding.ActivitySboardWriteBinding
import org.chaechae.sogong.utils.FBAuth
import org.chaechae.sogong.utils.FBRef
import java.io.ByteArrayOutputStream

class SBoardWriteActivity : AppCompatActivity() {

    private lateinit var binding:ActivitySboardWriteBinding

    private var isImageUpload=false

    private lateinit var category_selected:String


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sboard_write)

        binding=DataBindingUtil.setContentView(this,R.layout.activity_sboard_write)
        category_selected="전체"

        val getData=intent.getStringExtra("data")

        Log.d("SBoardWriteActivity",getData.toString())

        if(getData.equals("1")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="공지"
        } else if(getData.equals("2")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="정보"
        } else if(getData.equals("3")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="질의응답"
        } else if(getData.equals("4")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="스터디 기록"
        }else{
            setupSpinner()
            setupSpinnerHandler()
        }

        binding.writeBtn.setOnClickListener{

            val title=binding.titleArea.text.toString()
            val content=binding.contentArea.text.toString()
            val uid=FBAuth.getUid()
            val time=FBAuth.getTime()

            val key=FBRef.sBoardRef.push().key.toString()

            FBRef.sBoardRef
                .child(key)
                .setValue(SBoardModel(title,content,uid,time,category_selected))

            Toast.makeText(this,"게시글 입력 완료", Toast.LENGTH_LONG).show()

            if(isImageUpload==true){
                imageUpload(key)
            }

            finish()
        }

         binding.imageArea.setOnClickListener{
            val gallery=Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
             startActivityForResult(gallery,100)
             isImageUpload=true
         }


    }

    private fun imageUpload(key:String){

        val storage= Firebase.storage
        val storageRef=storage.reference
        val mountainsRef=storageRef.child(key+".png")

        val imageView=binding.imageArea
        imageView.isDrawingCacheEnabled=true
        imageView.buildDrawingCache()
        val bitmap=(imageView.drawable as BitmapDrawable).bitmap
        val baos=ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,baos)
        val data=baos.toByteArray()

        var uploadTask=mountainsRef.putBytes(data)
        uploadTask.addOnFailureListener{

        }.addOnSuccessListener{ taskSnapshot->

        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode== RESULT_OK&&requestCode==100){
            binding.imageArea.setImageURI(data?.data)
        }
    }

    private fun setupSpinner() {
        val category = resources.getStringArray(R.array.spinner_study_category)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, category)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinner.adapter = adapter
    }


    private fun setupSpinnerHandler() {

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                binding.textView.text = "카테고리: ${binding.spinner.getItemAtPosition(position)}"
                category_selected= binding.spinner.getItemAtPosition(position) as String

            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }

    }
}