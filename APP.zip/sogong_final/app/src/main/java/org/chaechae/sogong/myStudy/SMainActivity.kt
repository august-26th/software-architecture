package org.chaechae.sogong.myStudy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import org.chaechae.sogong.Board.BoardModel
import org.chaechae.sogong.Board.EntitleActivity
import org.chaechae.sogong.R
import org.chaechae.sogong.databinding.ActivitySmainBinding
import org.chaechae.sogong.utils.FBRef

class SMainActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySmainBinding

    private val sBoardDataList= mutableListOf<SBoardModel>()
    private val sBoardKeyList=mutableListOf<String>()

    private val TAG = SMainActivity::class.java.simpleName

    private lateinit var sBoardRVAdapter : SBoardListLVAdapter


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_smain)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_smain)

        binding.sHomeIcon.setOnClickListener {
            val intent=Intent(this, SMainActivity::class.java)
            startActivity(intent)
        }

        //게시글 카테고리
        binding.sSettingsIcon.setOnClickListener{
            val mDialogView=LayoutInflater.from(this).inflate(R.layout.smeun_dialog,null)
            val mBuilder=AlertDialog.Builder(this)
                .setView(mDialogView)
                .setTitle("카테고리")
            val alertDialog=mBuilder.show()

            //공지
            alertDialog.findViewById<Button>(R.id.noticeBtn)?.setOnClickListener {
                val intent=Intent(this, SMainActivity::class.java)
                intent.putExtra("data","1")
                startActivity(intent)
            }

            //정보
            alertDialog.findViewById<Button>(R.id.infoBtn)?.setOnClickListener {
                val intent=Intent(this,SMainActivity::class.java)
                intent.putExtra("data","2")
                startActivity(intent)
            }

            //질의응답
            alertDialog.findViewById<Button>(R.id.qnaBtn)?.setOnClickListener {
                val intent=Intent(this,SMainActivity::class.java)
                intent.putExtra("data","3")
                startActivity(intent)
            }



        }


        sBoardRVAdapter=SBoardListLVAdapter(sBoardDataList)
        binding.sBoardListView.adapter=sBoardRVAdapter

        binding.sBoardListView.setOnItemClickListener{parent,view,position,id->

            val intent=Intent(this, SBoardInsideActivity::class.java)
            intent.putExtra("key",sBoardKeyList[position])
            startActivity(intent)
        }

        val getData=intent.getStringExtra("data")

        binding.sBtnwrite.setOnClickListener{
            val intent= Intent(this,SBoardWriteActivity::class.java)
            intent.putExtra("data",getData)
            startActivity(intent)
        }

        getFBBoardData()



    }

    private fun getFBBoardData() {

        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                sBoardDataList.clear()

                for (dataModel in dataSnapshot.children) {

                    val getData=intent.getStringExtra("data")

                    if(getData.equals("1")) {
                        val item = dataModel.getValue(SBoardModel::class.java)
                        if (item?.category.equals("공지")) {
                            sBoardDataList.add(item!!)
                            sBoardKeyList.add(dataModel.key.toString())//파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }else if(getData.equals("2")) {
                        val item = dataModel.getValue(SBoardModel::class.java)
                        if (item?.category.equals("정보")) {
                            sBoardDataList.add(item!!)
                            sBoardKeyList.add(dataModel.key.toString())//파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }else if(getData.equals("3")) {
                        val item = dataModel.getValue(SBoardModel::class.java)
                        if (item?.category.equals("질의응답")) {
                            sBoardDataList.add(item!!)
                            sBoardKeyList.add(dataModel.key.toString())//파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }else if(getData.equals("4")) {
                        val item = dataModel.getValue(SBoardModel::class.java)
                        if (item?.category.equals("스터디 기록")) {
                            sBoardDataList.add(item!!)
                            sBoardKeyList.add(dataModel.key.toString())//파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }else{
                        val item = dataModel.getValue(SBoardModel::class.java)
                        sBoardDataList.add(item!!)
                        sBoardKeyList.add(dataModel.key.toString())
                    }



                }
                sBoardKeyList.reverse()
                sBoardDataList.reverse()
                sBoardRVAdapter.notifyDataSetChanged()

            }


            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG, "loadPost:onCancelled", databaseError.toException())
            }

        }
        FBRef.sBoardRef.addValueEventListener(postListener)
    }

}