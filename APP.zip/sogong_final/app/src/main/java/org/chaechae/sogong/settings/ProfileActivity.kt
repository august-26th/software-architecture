package org.chaechae.sogong.settings

import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContentProviderCompat.requireContext
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import org.chaechae.sogong.R
import java.util.*
import kotlin.collections.HashMap


class ProfileActivity : AppCompatActivity() {

    //메모리에 올라갔을 때
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        //객체 생성
        val nameText : TextView = findViewById(R.id.nameTextView)
//        val nameEdit : EditText = findViewById(R.id.nameEditText)
        val saveBtn : Button = findViewById(R.id.saveBtn)

        lateinit var databaseRef: DatabaseReference
        databaseRef = FirebaseDatabase.getInstance().reference
        val user = Firebase.auth.currentUser
        val uid = user?.uid.toString()

        //데이터베이스에 변경사항 있을 시 실행
        databaseRef.addValueEventListener(object : ValueEventListener{
            override fun onDataChange (snapshot: DataSnapshot){
                val map = snapshot.child("Users").children.iterator().next().getValue() as HashMap <String, Any>
                val name = map.get("name").toString()
                nameText.setText("${name} 님")
            }
            override fun onCancelled(error: DatabaseError){
            }
        })

//        saveBtn?.setOnClickListener{
//            if(nameEdit?.text!!.isNotEmpty()){
//                databaseRef.child("Users/$uid/name").setValue(nameEdit.text.toString())
//                nameEdit.clearFocus()
//            }
//        }

    }

}