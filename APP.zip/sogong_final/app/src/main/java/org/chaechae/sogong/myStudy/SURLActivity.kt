package org.chaechae.sogong.myStudy

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import org.chaechae.sogong.R

class SURLActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        val saveBtn=findViewById<Button>(R.id.saveBtn)


        saveBtn.setOnClickListener {


            Toast.makeText(this,"입력 완료", Toast.LENGTH_LONG).show()
        }





    }
}