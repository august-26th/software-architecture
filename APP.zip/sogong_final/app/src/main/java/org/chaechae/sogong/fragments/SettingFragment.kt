package org.chaechae.sogong.fragments

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.findNavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.ktx.Firebase
import org.chaechae.sogong.Board.BoardWriteActivity
import org.chaechae.sogong.LoginActivity
import org.chaechae.sogong.R
import org.chaechae.sogong.SigninActivity
import org.chaechae.sogong.settings.DelveloperInfoActivity
import org.chaechae.sogong.settings.PrivacyPolicyActivity
import org.chaechae.sogong.settings.ProfileActivity

class SettingFragment : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        val view=inflater.inflate(R.layout.fragment_setting,container,false)

       //이름
        lateinit var databaseRef: DatabaseReference
        databaseRef = FirebaseDatabase.getInstance().reference

        //데이터베이스에 변경사항 있을 시 실행
        databaseRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange (snapshot: DataSnapshot){
                val map = snapshot.child("Users").children.iterator().next().getValue() as HashMap <String, Any>
                val name = map.get("name").toString()
                view.findViewById<TextView>(R.id.textView4).setText("${name} 님")
            }
            override fun onCancelled(error: DatabaseError){
            }
        })


        //프로필 수정
        view.findViewById<ImageView>(R.id.imageView2).setOnClickListener{
            val intent=Intent(context, ProfileActivity::class.java)
            startActivity(intent)
        }

        //'어플 사용 설명' 클릭 시
        view.findViewById<TextView>(R.id.textView5).setOnClickListener{
            val intent=Intent(Intent.ACTION_VIEW, Uri.parse("https://educated-harmony-688.notion.site/a2879b7163ba484c9c2e43a20fde2774"))
            startActivity(intent)
        }
        //'개인정보처리방침' 클릭 시
        view.findViewById<TextView>(R.id.textView6).setOnClickListener{
            val intent=Intent(context, PrivacyPolicyActivity::class.java)
            startActivity(intent)
        }
        //'개발자 정보' 클릭 시
        view.findViewById<TextView>(R.id.textView7).setOnClickListener{
            val intent=Intent(context, DelveloperInfoActivity::class.java)
            startActivity(intent)
        }
        //'로그아웃' 클릭 시
        view.findViewById<TextView>(R.id.textView9).setOnClickListener{
            FirebaseAuth.getInstance().signOut()

            Toast.makeText(context,"로그아웃",Toast.LENGTH_LONG).show()
            val intent=Intent(context, LoginActivity::class.java)
            intent.flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }


        return view
    }


}