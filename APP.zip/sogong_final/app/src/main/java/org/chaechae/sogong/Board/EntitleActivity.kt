package org.chaechae.sogong.Board

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import androidx.databinding.DataBindingUtil
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import org.chaechae.sogong.R
import org.chaechae.sogong.databinding.ActivityBoardWriteBinding
import org.chaechae.sogong.databinding.ActivityEntitleBinding
import org.chaechae.sogong.utils.FBRef

class EntitleActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEntitleBinding

    private val boardDataList = mutableListOf<BoardModel>()
    private val boardKeyList=mutableListOf<String>()

    private val TAG = EntitleActivity::class.java.simpleName

    private lateinit var boardRVAdapter:BoardListLVAdapter

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entitle)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_entitle)


        boardRVAdapter = BoardListLVAdapter(boardDataList)
        binding.boardListView.adapter = boardRVAdapter
        binding.boardListView.setOnItemClickListener{parent,view,position,id->

            val intent=Intent(this,BoardInsideActivity::class.java)
            intent.putExtra("key",boardKeyList[position])
            startActivity(intent)

        }

        val getData=intent.getStringExtra("data")

        binding.btnwrite.setOnClickListener {
            val intent = Intent(this, BoardWriteActivity::class.java)
            intent.putExtra("data",getData)
            startActivity(intent)
        }

        getFBBoardData()

    }

    private fun getFBBoardData() {

        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {

                boardDataList.clear()

                for (dataModel in dataSnapshot.children) {

                    val getData=intent.getStringExtra("data")

                    if(getData.equals("1")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        boardDataList.add(item!!)
                        boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                    }


                    if(getData.equals("2")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("어학")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }

                    if(getData.equals("3")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("취업")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }

                    if(getData.equals("4")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("입시")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }

                    if(getData.equals("5")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("IT")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }

                    if(getData.equals("6")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("고시")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }

                    if(getData.equals("7")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("취미")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }

                    if(getData.equals("8")){
                        val item = dataModel.getValue(BoardModel::class.java)
                        if(item?.category.equals("기타")){
                            boardDataList.add(item!!)
                            boardKeyList.add(dataModel.key.toString()) //파이어베이스로부터 게시 글 UID(key값) 받아옴
                        }
                    }



                }
                boardKeyList.reverse()
                boardDataList.reverse()
                boardRVAdapter.notifyDataSetChanged()


            }


            override fun onCancelled(databaseError: DatabaseError) {
                Log.w(TAG,"loadPost:onCancelled",databaseError.toException())
            }
        }
        FBRef.boardRef.addValueEventListener(postListener)
    }
}