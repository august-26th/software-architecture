package org.chaechae.sogong.Board

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.databinding.DataBindingUtil
import org.chaechae.sogong.R
import org.chaechae.sogong.databinding.ActivityBoardWriteBinding
import org.chaechae.sogong.utils.FBAuth
import org.chaechae.sogong.utils.FBRef

class BoardWriteActivity : AppCompatActivity() {

    private lateinit var binding : ActivityBoardWriteBinding
    private lateinit var category_selected:String

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding=DataBindingUtil.setContentView(this, R.layout.activity_board_write)
        category_selected="전체"

        val getData=intent.getStringExtra("data")

        if(getData.equals("1")){
            setupSpinner()
            setupSpinnerHandler()
        }

        if(getData.equals("2")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="어학"
        }

        if(getData.equals("3")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="취업"
        }

        if(getData.equals("4")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="입시"
        }

        if(getData.equals("5")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="IT"
        }

        if(getData.equals("6")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="고시"
        }

        if(getData.equals("7")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="취미"
        }

        if(getData.equals("8")){
            binding.layoutVisible.setVisibility(View.GONE)
            category_selected="ETC"
        }


        binding.writeBtn.setOnClickListener{
            Log.d("BoardWriteActivity",category_selected)
            val title=binding.titleArea.text.toString();
            val content=binding.contentArea.text.toString();
            val uid=FBAuth.getUid()
            val time=FBAuth.getTime()

            val key=FBRef.boardRef.push().key.toString()

            FBRef.boardRef
                .child(key)//랜덤값 생성됨
                .setValue(BoardModel(title,content ,uid ,time,category_selected))

            Toast.makeText(this,"게시글 입력 완료",Toast.LENGTH_LONG).show()

            finish()
        }

    }

    private fun setupSpinner() {
        val category = resources.getStringArray(R.array.spinner_category)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, category)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinner.adapter = adapter
    }


    private fun setupSpinnerHandler() {

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                binding.textView.text = "카테고리: ${binding.spinner.getItemAtPosition(position)}"
                category_selected= binding.spinner.getItemAtPosition(position) as String
                Log.d("BoardWriteActivity",category_selected)
            }
            override fun onNothingSelected(p0: AdapterView<*>?) {
            }
        }

    }
}